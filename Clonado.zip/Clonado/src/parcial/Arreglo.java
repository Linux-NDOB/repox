package parcial;

import javax.swing.*;
import java.util.ArrayList;

public class Arreglo {


        private ArrayList arreglo;

        public Arreglo( ){
            arreglo = new ArrayList();
        }

        int getBuscarId(int id){
            int i;
            Pojo aux=null;
            for(i=0; i<arreglo.size(); i++){
                aux = (Pojo) arreglo.get(i);
                if(id == aux.getId())
                    return i;
            }
            return -1;
        }

        void setPais( ){
            int id, pos;

            do{
                id=Integer.parseInt(JOptionPane.showInputDialog(
                        "Entre id: "));
                pos=getBuscarId(id);
                if(pos>=0)
                    JOptionPane.showMessageDialog(null,
                            "El idE ya se encuentra registrado.  Intente nuevamente!");
            }while(pos>=0);

            String nombre=JOptionPane.showInputDialog(
                    "Entre nombre del pais: ");

            float superficie=Float.parseFloat(JOptionPane.showInputDialog(
                    "Entre la superficie: "));


            String idiomaNacional=JOptionPane.showInputDialog(
                    "Entre idioma del pais: ");

            String moneda=JOptionPane.showInputDialog(
                    "Entre nombre de moneda del pais: ");

            String Npresidente=JOptionPane.showInputDialog(
                    "Entre nombre del presidente del pais: ");



            Paiss info = new Paiss(id, nombre, superficie,idiomaNacional, moneda, Npresidente);

            arreglo.add(info);
            JOptionPane.showMessageDialog(null, "Registrado!!");
        }

        void setProvincia( ){
            int id, pos;

            do{
                id=Integer.parseInt(JOptionPane.showInputDialog(
                        "Entre id: "));
                pos=getBuscarId(id);
                if(pos>=0)
                    JOptionPane.showMessageDialog(null,
                            "El idE ya se encuentra registrado.  Intente nuevamente!");
            }while(pos>=0);

            String nombre=JOptionPane.showInputDialog(
                    "Entre nombre de Provincia: ");

            float superficie=Float.parseFloat(JOptionPane.showInputDialog(
                    "Entre la superficie: "));


            int idPais= Integer.parseInt(JOptionPane.showInputDialog(
                    "Entre id de la provincia: "));

            String gobernador=JOptionPane.showInputDialog(
                    "Entre nombre de gobernador: ");


            Provincia info = new Provincia(id, nombre, superficie, idPais, gobernador);

            arreglo.add(info);

            JOptionPane.showMessageDialog(null, "Registrado!!");
        }

        public void mostrarTodo(){

            int i;

            Pojo aux = null;

            Provincia ste=null;

            Paiss paux=null;

            for(i=0; i<arreglo.size(); i++){

                aux = (Pojo) arreglo.get(i);


                for(i=0; i<arreglo.size(); i++) {

                    if ((aux.tipoLugar).equals("Pais")) {

                        paux = (Paiss) arreglo.get(i);
                        paux.informacion();

                    } else if ((aux.tipoLugar).equals("Provincia")) {

                        ste = (Provincia) arreglo.get(i);
                        ste.informacion();

                    }
                }}}






        public void getPersona(int identificacion){

            Pojo aux=null;

            Paiss paux=null;

            Provincia ste=null;

            int i;

            int buscar=getBuscarId(identificacion);


            if(buscar==-1)
                JOptionPane.showMessageDialog(null,
                        "NO existe!");
            else{

                aux = (Pojo) arreglo.get(buscar);


                if((aux.tipoLugar).equals("Pais")){

                    paux = (Paiss) arreglo.get(buscar);
                    paux.informacion();

                }else if((aux.tipoLugar).equals("Provincia")) {

                    ste = (Provincia) arreglo.get(buscar);
                    ste.informacion();
                }
            }
        }


    }
