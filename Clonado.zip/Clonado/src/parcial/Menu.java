package parcial;

import javax.swing.*;

public class Menu {

    public static void main(String[] args) {


            int Opcion,Salir;
            int identificacion = 0;


            Arreglo main =new Arreglo();


            do {



                Opcion=Integer.parseInt(JOptionPane.showInputDialog(

                        "     ----------------Main Menu----------------\n"+"\n"+

                                "1. Registrar  \n"+"\n"+

                                "2. Mostrar todos  \n"+"\n"+

                                "3. Buscar por id .  \n"+"\n"+

                                "4. Exit \n   " + " \n" +


                                " Please enter an option : "));


                switch(Opcion){
                    case 1:



                            String type;
                            Object Tipo[] = {"Provincia" , "Pais"};
                            Object B = JOptionPane.showInputDialog(null,"Seleccion \n"
                                            +"Pais","Opciones",
                                    JOptionPane.QUESTION_MESSAGE,null,Tipo, Tipo[0]);
                            type = B.toString();

                            if(B.equals("Provincia")){
                                main.setProvincia();
                            }else if(B.equals("Pais")) {
                                main.setPais();
                            }




                        break;

                    case 2:
                        if(main==null)
                            JOptionPane.showMessageDialog(null, "Vector vacio!");
                        else
                            main.mostrarTodo();
                        break;


                    case 3:

                        if(main==null)
                            JOptionPane.showMessageDialog(null, "Vector vacio!");
                        else
                            identificacion = Integer.parseInt(JOptionPane.showInputDialog("Ingrese id"));
                            main.getPersona(identificacion);


                        break;

                    case 4:
                        Salir =JOptionPane.showConfirmDialog(null, "¿desea salir?");
                        if (Salir==0) {

                            break;
                        }
                    default:

                        JOptionPane.showMessageDialog(null, "Opcion invalida ");

                        break;

                }


            }while (Opcion != 4);


            System.exit(0);


    }

}
