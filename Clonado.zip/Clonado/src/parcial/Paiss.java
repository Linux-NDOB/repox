package parcial;

import javax.swing.*;

public  class Paiss extends  Pojo{

    private String idiomaNacional;
    private String moneda;
    private String Npresidente;

    public Paiss(int id, String nombre, float superficie, String idioma, String moneda, String presidente) {
        super(id, nombre, superficie, "Pais");
        this.idiomaNacional = idiomaNacional;
        this.moneda = moneda;
        this.Npresidente = Npresidente;

    }

    public String getIdiomaNacional() {
        return idiomaNacional;
    }

    public void setIdiomaNacional(String idiomaNacional) {
        this.idiomaNacional = idiomaNacional;
    }

    public String getMoneda() {
        return moneda;
    }

    public void setMoneda(String moneda) {
        this.moneda = moneda;
    }

    public String getNpresidente() {
        return Npresidente;
    }

    public void setNpresidente(String npresidente) {
        Npresidente = npresidente;
    }

    public void informacion(){
        String info="Informacion: \n";
        info += "id: "+id+"\n";
        info += "nombre: "+nombre+"\n";
        info += "superficie: "+superficie+"\n";
        info += "idioma: "+idiomaNacional+"\n";
        info += "moneda:"+moneda+"\n";
        info += "presidente:"+Npresidente+"\n";
        JOptionPane.showMessageDialog(null, info);
    }
}
