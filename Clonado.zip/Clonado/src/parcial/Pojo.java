package parcial;

import javax.swing.JOptionPane;

public class Pojo {


        public int id;

        public String nombre;

        public float superficie;

        public String tipoLugar;

        public Pojo(int id, String nombre, float superficie, String tipoLugar) {
            this.id = id;
            this.nombre = nombre;
            this.superficie = superficie;
            this.tipoLugar = tipoLugar;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getNombre() {
            return nombre;
        }

        public void setNombre(String nombre) {
            this.nombre = nombre;
        }

        public float getSuperficie() {
            return superficie;
        }

        public void setSuperficie(float superficie) {
            this.superficie = superficie;
        }

        public String getTipoLugar() {
            return tipoLugar;
        }

        public void setTipoLugar(String tipoLugar) {
            this.tipoLugar = tipoLugar;
        }



}
