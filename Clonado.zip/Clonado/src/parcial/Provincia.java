package parcial;

import javax.swing.*;

public class Provincia extends Pojo{

    public int idPais;
    public String gobernador;


    public Provincia(int id, String nombre, float superficie,  int idPais, String gobernador) {
        super(id, nombre, superficie, "Provincia");
        this.idPais = idPais;
        this.gobernador = gobernador;
    }

    public int getIdPais() {
        return idPais;
    }

    public void setIdPais(int idPais) {
        this.idPais = idPais;
    }

    public String getGobernador() {
        return gobernador;
    }

    public void setGobernador(String gobernador) {
        this.gobernador = gobernador;
    }



    public void informacion(){
        String info="Informacion: \n";
        info += "id: "+id+"\n";
        info += "nombre: "+nombre+"\n";
        info += "superficie: "+superficie+"\n";
        info += "idioma: "+idPais+"\n";
        info += "moneda:"+gobernador+"\n";

        JOptionPane.showMessageDialog(null, info);
    }
}
