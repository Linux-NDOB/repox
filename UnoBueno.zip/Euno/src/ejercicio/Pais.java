package ejercicio;

import javax.swing.*;

public class Pais extends info{

    private String idioma;
    private String moneda;
    private String presidente;

    public Pais(int id, String nombre, float superficie, String idioma, String moneda, String presidente) {
        super(id, nombre, superficie, "Pais");
        this.idioma = idioma;
        this.moneda = moneda;
        this.presidente = presidente;

    }

    public String getIdioma() {
        return idioma;
    }

    public void setIdioma(String idioma) {
        this.idioma = idioma;
    }

    public String getMoneda() {
        return moneda;
    }

    public void setMoneda(String moneda) {
        this.moneda = moneda;
    }

    public String getPresidente() {
        return presidente;
    }

    public void setPresidente(String presidente) {
        this.presidente = presidente;
    }

    public void informacion(){
        String info="Informacion: \n";
        info += "id: "+id+"\n";
        info += "nombre: "+nombre+"\n";
        info += "superficie: "+superficie+"\n";
        info += "idioma: "+idioma+"\n";
        info += "moneda:"+moneda+"\n";
        info += "presidente:"+presidente+"\n";
        JOptionPane.showMessageDialog(null, info);
    }
}
