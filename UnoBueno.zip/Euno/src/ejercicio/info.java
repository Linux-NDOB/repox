package ejercicio;

import javax.swing.*;

public class info {

    public int id;

    public String nombre;

    public float superficie;

    public String tipo;

    public info(int id, String nombre, float superficie, String tipo) {
        this.id = id;
        this.nombre = nombre;
        this.superficie = superficie;
        this.tipo = tipo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getSuperficie() {
        return superficie;
    }

    public void setSuperficie(float superficie) {
        this.superficie = superficie;
    }

    public void getInformation(){
        String dat="";
        dat+="Los datos registrados son:\n";
        dat+="Id: "+id+"\n";
        dat+="Nombre: "+nombre+"\n";
        dat+="Superficie: "+superficie+"\n";

        JOptionPane.showMessageDialog(null, dat);
    }
}
