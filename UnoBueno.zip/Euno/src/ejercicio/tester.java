package ejercicio;

import javax.swing.*;

public class tester {
        public static void main(String[] args) {

            try{
                int Option,Exit;
                int identification;

                vectorx main =new vectorx();


                do {



                    Option=Integer.parseInt(JOptionPane.showInputDialog(

                            "     ----------------Main Menu----------------\n"+"\n"+

                                    "1. Registrar Pais o Provincia \n"+"\n"+

                                    "2. Mostrar todos  \n"+"\n"+

                                    "3. Buscar por id de zona geografica.  \n"+"\n"+

                                    "4. Exit \n   " + " \n" +


                                    " Please enter an option : "));


                    switch(Option){
                        case 1:

                            try{

                                String type;
                                Object TypeA[] = {"Provincia" , "Pais"};
                                Object P = JOptionPane.showInputDialog(null,"¿wich type of? \n"
                                                +"Pais","Opciones",
                                        JOptionPane.QUESTION_MESSAGE,null,TypeA, TypeA[0]);
                                type = P.toString();

                                if(P.equals("Provincia")){
                                    main.setAddProvincia();
                                }else if(P.equals("Pais")) {
                                    main.setAddPais();
                                }

                            }catch(NegativeArraySizeException a) {

                                JOptionPane.showMessageDialog(null, "Numeros positivos");
                            }



                            break;

                        case 2:
                            if(main==null)
                                JOptionPane.showMessageDialog(null, "Vector vacio!");
                            else{
                                main.mostrar();

                            }
                            break;


                        case 3:

                            if(main==null)
                                JOptionPane.showMessageDialog(null, "Vector vacio!");
                            else{
                                try{
                                     identification = Integer.parseInt(JOptionPane.showInputDialog("Ingrese id"));
                                    main.getShowPerson(identification);
                                } catch(NumberFormatException b){
                                    JOptionPane.showMessageDialog(null, "Solo numeros");
                                }
                            }
                            break;

                        case 4:
                            Exit=JOptionPane.showConfirmDialog(null, "¿desea salir?");
                            if (Exit==0) {

                                break;
                            }
                        default:

                            JOptionPane.showMessageDialog(null, "Opcion invalida ");

                            break;

                    }


                }while (Option != 4);


                System.exit(0);


            } catch(NumberFormatException a){

                JOptionPane.showMessageDialog(null, "Error, intente de nuevo");


            }
        }

    }


