package ejercicio;

import java.util.ArrayList;
//Librerías para generar nuestro propio JTable
import javax.swing.JOptionPane;

public class vectorx {


        private ArrayList  vectorr;

        public vectorx( ){
            vectorr = new ArrayList();
        }

        int getBuscarId(int id){
            int i;
            info aux=null;
            for(i=0; i<vectorr.size(); i++){
                aux = (info) vectorr.get(i);
                if(id == aux.getId())
                    return i;
            }
            return -1;
        }

        void setAddPais( ){
            int id, pos;

            do{
                id=Integer.parseInt(JOptionPane.showInputDialog(
                        "Entre id: "));
                pos=getBuscarId(id);
                if(pos>=0)
                    JOptionPane.showMessageDialog(null,
                            "El idE ya se encuentra registrado.  Intente nuevamente!");
            }while(pos>=0);

            String nombre=JOptionPane.showInputDialog(
                    "Entre nombre del pais: ");

            float superficie=Float.parseFloat(JOptionPane.showInputDialog(
                    "Entre la superficie: "));


            String idioma=JOptionPane.showInputDialog(
                    "Entre idioma del pais: ");

            String moneda=JOptionPane.showInputDialog(
                    "Entre nombre de moneda del pais: ");

            String presidente=JOptionPane.showInputDialog(
                    "Entre nombre del presidente del pais: ");



            Pais info = new Pais(id, nombre, superficie,idioma, moneda, presidente);

            vectorr.add(info);
            JOptionPane.showMessageDialog(null, "Registrado!!");
        }

    void setAddProvincia( ){
        int id, pos;

        do{
            id=Integer.parseInt(JOptionPane.showInputDialog(
                    "Entre id: "));
            pos=getBuscarId(id);
            if(pos>=0)
                JOptionPane.showMessageDialog(null,
                        "El idE ya se encuentra registrado.  Intente nuevamente!");
        }while(pos>=0);

        String nombre=JOptionPane.showInputDialog(
                "Entre nombre de Provincia: ");

        float superficie=Float.parseFloat(JOptionPane.showInputDialog(
                "Entre la superficie: "));


        int idPais= Integer.parseInt(JOptionPane.showInputDialog(
                "Entre id de la provincia: "));

        String gobernador=JOptionPane.showInputDialog(
                "Entre nombre de gobernador: ");


        Provincia info = new Provincia(id, nombre, superficie, idPais, gobernador);

        vectorr.add(info);

        JOptionPane.showMessageDialog(null, "Registrado!!");
    }

    public void mostrar(){

        int i;

        info aux = null;

        Provincia ste=null;

        Pais paux=null;

        for(i=0; i<vectorr.size(); i++){

            aux = (info) vectorr.get(i);


            for(i=0; i<vectorr.size(); i++) {

                if ((aux.tipo).equals("Pais")) {

                    paux = (Pais) vectorr.get(i);
                    paux.informacion();

                } else if ((aux.tipo).equals("Provincia")) {

                    ste = (Provincia) vectorr.get(i);
                    ste.informacion();

                }
            }}}






    public void getShowPerson(int id){

        info aux=null;

        Pais paux=null;

        Provincia ste=null;

        int i;

        int buscar=getBuscarId(id);


        if(buscar==-1)
            JOptionPane.showMessageDialog(null,
                    "NO existe!");
        else{

            aux = (info) vectorr.get(buscar);


            if((aux.tipo).equals("Pais")){

                paux = (Pais) vectorr.get(buscar);
                paux.informacion();

            }else if((aux.tipo).equals("Provincia")) {

                ste = (Provincia) vectorr.get(buscar);
                ste.informacion();
            }
        }
    }


}